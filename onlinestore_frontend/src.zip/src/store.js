import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex);

export const store = new Vuex.Store({

    state:{
        wishlist:[],
        cart:[],
        categories:[{id:1,name:"All Books",images:['library.jpg']},{id:2,name:"All Music",images:['Music.png']},{id:3,name:"All DVDs",images:['Films.jpg']}],
        searchProducts:[],
    },

    

});
