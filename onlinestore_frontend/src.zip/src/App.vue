<template>
  <div id="app">
    <Header />

    <router-view> <Homepage /> </router-view>
  </div>
</template>

<script>
import Homepage from './components/HomePage.vue';
import Header from './components/Header-notloggedin.vue';

export default {
  name: 'App',
  components: {
    Header,
    Homepage
  } 
};
</script>

<style>
#app {
font-family: vortice-concept, sans-serif;
  font-style: normal;
  font-weight: 400;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #063764;
  
  margin-top: 10px;
  display: grid;
  grid-template-rows: auto;
  grid-template-columns: repeat(1, 100%);
}
</style>
