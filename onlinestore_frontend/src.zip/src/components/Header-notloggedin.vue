<template>

<div class="container">
<b-navbar fixed="top"  toggleable="lg">
    <b-navbar-brand to="/"><img style= "width : 100px;height : 100px;float: left;margin-left: 10px;" src="@/assets/logo_transparent.png"/></b-navbar-brand>

    <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>

    <b-collapse id="nav-collapse" is-nav>
      <b-navbar-nav>
        <b-nav-item-dropdown  text="Books" right>
             <b-dropdown-item to="/maincategorybooks" > All Books</b-dropdown-item>
             <b-dropdown-item to="/Literature/">Literature</b-dropdown-item>
         </b-nav-item-dropdown>
        <b-nav-item-dropdown  text="Music" right>
             <b-dropdown-item to="/maincategorymusic" > All Music</b-dropdown-item>
             <b-dropdown-item to="/signup/">Pop</b-dropdown-item>
         </b-nav-item-dropdown>
         <b-nav-item-dropdown text="DVD" right>
             <b-dropdown-item to="/maincategorydvd"> All DVD</b-dropdown-item>
             <b-dropdown-item to="/signup/">Horror</b-dropdown-item>
         </b-nav-item-dropdown>
      </b-navbar-nav>

      <!-- Right aligned nav items -->
      <b-navbar-nav class="navbar-nav ml-auto">
        <b-nav-form class="nav-form">
          <b-form-input v-model="text" size="sm" class="search mr-sm-2" placeholder="Search"></b-form-input>
          <b-button size="sm" class="button my-2 my-sm-0" type="submit" to="/SearchResults/" @click="Search()" >Search</b-button>
        </b-nav-form>

        <b-nav-item-dropdown right>
          <!-- Using 'button-content' slot -->
          <template  v-slot:button-content>
            <i class="fas fa-user-circle"></i>
          </template>
          <b-dropdown-item to="/login">Login</b-dropdown-item>
          <b-dropdown-item to="/signup">Sign Up</b-dropdown-item>
        </b-nav-item-dropdown>

        <b-nav-item-dropdown  style="margin-right:30px;" right>
            <template  v-slot:button-content>
            <i class="fas fa-shopping-cart"></i>
          </template>
            
                <li> <shoppingcart/> </li>
        </b-nav-item-dropdown>
      </b-navbar-nav >
    </b-collapse>
    
  </b-navbar>
  
  
</div>
</template>

<script>
import router from '../router/index.js'
import shoppingcart from './ShoppingCart.vue'
import axios from 'axios';
export default {
    name: 'Header',

    components: shoppingcart,
    data (){
        return {
                modal:false,
                isPanelOpen: true,
                text:'',
              }
    },

    methods :{

        modalAction(){
            if(this.modal==false){this.modal=true;this.isPanelOpen=true;}
                else{this.modal=false;}
        
        },
         closeSidebarPanel() {
                this.isPanelOpen = false;
                if(this.modal==false){this.modal=true;}
                else{this.modal=false;}
            }
            ,
         Search() {
                console.log(this.text);
                axios.post("http://localhost:8090/search/"+ this.text)
                .then(response=> this.$store.state.searchProducts = response.data)
    
            }

       
    },

};
</script>

<style scoped>
   .mynav{
   
    height:500px;
}
.navbar{
    background-image:url('../assets/header7.png');

}

.navbar .navbar-nav{
    margin : 10 auto;
    font-size: 1.4em;
    font-family: droid-sans, sans-serif !important;
    font-style: normal;
    font-weight: 400;
    
        
  
}


.navbar-nav .nav-form .button{
    background-color:#DCAD8C;
    color:white;
    border:2;
     margin-right:30px;
}
.navbar-nav .nav-form .search{
    background-color: white;
    padding-right:20px;
    
}



    
.container{

        text-align: center;
        margin-right:10%;
        margin-bottom: 10%;
       

    }
    
    
   
   
    

    
</style>