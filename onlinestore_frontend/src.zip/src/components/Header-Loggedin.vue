<template>

<div class="container">
<b-navbar   fixed="top" variant ="light" toggleable="lg" v-if="!modal">
    <b-navbar-brand to="/"><img src="@/assets/logo_transparent.png"/></b-navbar-brand>

    <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>

    <b-collapse id="nav-collapse" is-nav>
      <b-navbar-nav>
        <b-nav-item-dropdown text="Books" right>
             <b-dropdown-item :to="{ name:'maincategory', params: {id: 1}}" replace> All Books</b-dropdown-item>
             <b-dropdown-item to="/signup/">Literature</b-dropdown-item>
         </b-nav-item-dropdown>
        <b-nav-item-dropdown text="Music" right>
             <b-dropdown-item :to="{ name:'maincategory', params: {id: 2}}" replace> All Music</b-dropdown-item>
             <b-dropdown-item to="/signup/">Pop</b-dropdown-item>
         </b-nav-item-dropdown>
         <b-nav-item-dropdown text="DVD" right>
             <b-dropdown-item :to="{ name:'maincategory', params: {id: 3}}" replace> All DVD</b-dropdown-item>
             <b-dropdown-item to="/signup/">Horror</b-dropdown-item>
         </b-nav-item-dropdown>
      </b-navbar-nav>

      <!-- Right aligned nav items -->
      <b-navbar-nav class="ml-auto">
        <b-nav-form>
          <b-form-input size="sm" class="mr-sm-2" placeholder="Search"></b-form-input>
          <b-button size="sm" class="my-2 my-sm-0" type="submit">Search</b-button>
        </b-nav-form>


        <b-nav-item-dropdown right>
          <!-- Using 'button-content' slot -->
          <i class="fas fa-bell"></i>
          <template v-slot:button-content>
            <em>User</em>
          </template>
          <b-dropdown-item href="#">Profile</b-dropdown-item>
          <b-dropdown-item href="#">My WishList</b-dropdown-item>
          <b-dropdown-item href="#">Sign Out</b-dropdown-item>
        </b-nav-item-dropdown>
        <b-icon style="margin-top:10px;" icon="bag"  @click="modalAction()"></b-icon>
      </b-navbar-nav>
    </b-collapse>
    
  </b-navbar>
  <div class="sidebar" v-if="modal">
                    <div class="sidebar-backdrop" @click="closeSidebarPanel" v-if="isPanelOpen"></div>
                    <transition name="slide">
                        <div v-if="isPanelOpen"
                            class="sidebar-panel">
                            <shoppingcart/>
                            <slot> </slot>
                        </div>
                    </transition>
                
    </div>
  
</div>
</template>

<script>
import router from '../router/index.js'
import shoppingcart from './ShoppingCart.vue'
export default {
    name: 'Header',

    components: shoppingcart,
    data (){
        return {
                modal:false,
                isPanelOpen: true
              }
    },

    methods :{

        modalAction(){
            if(this.modal==false){this.modal=true;this.isPanelOpen=true;}
                else{this.modal=false;}
        
        },
         closeSidebarPanel() {
                this.isPanelOpen = false;
                if(this.modal==false){this.modal=true;}
                else{this.modal=false;}
            }

       
    },

};
</script>

<style scoped>
    
    .container{

        text-align: center;
        margin-right:10%;
        margin-bottom: 10%;
        background-color: rgba(206, 80, 7, 0.5);;

    }
    
    img{
        width :    100px;
        height : 100px;
        float: left;
        margin-left: 10px;

    }
    

    .slide-enter-active,
    .slide-leave-active
    {
        transition: transform 3s ease;
    }

    .slide-enter,
    .slide-leave-to {
        transform: translateX(-100%);
        transition: all 1 ms ease-in 2s
    }

    .sidebar-backdrop {
        background-color: rgba(192, 186, 184, 0.575);
        width: 100vw;
        height: 100vh;
        position: fixed;
        top: 0;
        right: 0;
        cursor: pointer;
    }

    .sidebar-panel {
        overflow-y: auto;
        background-color:  rgba(192, 186, 184, 0.911);
        position: fixed;
        right: 0;
        top: 0;
        height: 100vh;
        z-index: 999;
        padding: 3rem 20px 2rem 20px;
        width: 400px;
    }
    

    
</style>