<template>
<div class="login" :style="{backgroundImage:'url(https://i.redd.it/uzhvhkspggx01.jpg)'}">
    <div class="spark-screen container">
         <div class="row justify-content-center">
    <!-- Default form login -->
<form class="text-center border border-light p-5" action="#!">

    <h3><p class="h4 mb-4"><b>Login To Your Account</b></p></h3>

    <!-- Email -->
    <input type="email" id="LoginEmail" class="form-control mb-4" placeholder="E-mail">

    <!-- Password -->
    <input type="password" id="LoginPassword" class="form-control mb-4" placeholder="Password">

    <div class="d-flex justify-content-around">
        <div>
            <!-- Forgot password -->
            <a href="#/resetPassword">Forgot password?</a>
        </div>
    </div>

    <!-- Sign in button -->
    <div class="pink"><b-button variant="outline-danger" v-on:click="OnLoginClick" class=" btn-block my-1" type="submit">Sign in</b-button></div>

    <!-- Register -->
    <p>Not a member?
        <a href="#/Signup">Sign Up</a>
    </p>


</form>
<!-- Default form login -->


</div>
</div>
</div>
</template>

<script>
import axios from 'axios';
export default {
    name:'login',
    data () {
       return {
            LoginEmail:'',
            LoginPassword:''
       }
    },

    methods: {
      OnLoginClick() {
       //VUEX IS NEEDED FOR THAT ON CLICK METHOD
       if(this.input.LoginEmail != "" && this.input.LoginPassword != "") {
                    if(this.input.LoginEmail == this.$parent.mockAccount.LoginEmail && this.input.LoginPassword == this.$parent.mockAccount.LoginPassword) {
                        this.$emit("authenticated", true);
                        this.$router.replace({ name: "secure" });
                    } else {
                        console.log("The username and / or password is incorrect");
                    }
                } else {
                    console.log("A username and password must be present");
                }
            }
    }
}

</script>

<style lang="stylus" scoped>
#login {
        width: 500px;
        border: 1px solid #CCCCCC;
}
.card {
            background-color: rgba(300, 228, 255, 0.2);
        }

</style>


