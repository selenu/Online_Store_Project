<template>
 <div class="container">
     <ul  class="dropdown-cart" role="menu"> 
              <li v-for="item in cart" :key="item.pId" class="d-flex flex-row"> 
                  <span class="item">
                    <span class="item-left">
                        <img v-bind:src="item.image" class="thumbnail" alt="" />
                        <span style="margin-left:5px; " class="d-2 item-info">
                            
                           
                            <span>{{ item.pName.substring(0,15)+".." }}</span>
                            <span>${{ item.price }}</span>
                            <span>Quantity: {{ item.quantity }}</span>
                        </span>
                    </span>
                    <span class="d-flex justify-content-end item-right">
                        <button @click="removeFromCart(item.pId)" class="btn btn-xs btn-danger pull-right">x</button>
                    </span>
                </span>
              </li>
              
     </ul>
     <b-button style="margin-top:90px; margin-left:80px;" to="/checkout/" size="lg" class="my-2 my-sm-0">Checkout</b-button>
 </div>

      
  

</template>

<script>
import axios from 'axios';
export default {
    name: 'shoppingcart',

    data() {
        return {
        cart: []
        }
    }
    ,

    methods: {

    removeFromCart(pid) {
      axios.delete("http://localhost:8090/shoppingCart/delete-By-Id?cId=2&pId="+pid)
       .catch(() => console.log(pid));
    }
  },

 

    mounted () {
    axios
      .get('http://localhost:8090/shoppingCart/get-products-By-Id?id=2',)
      .then(response => (this.cart = response.data))
      .catch(() => console.log('cart.vue'));
  },
    updated(){
    axios
      .get('http://localhost:8090/shoppingCart/get-products-By-Id?id=2')
      .then(response => (this.cart = response.data))
      .catch(() => console.log('cart.vue'));
  }

    
}
</script>

<style  scoped>

cart-list {
  width: 70%;
  @media only screen and (max-width: 832px) {
    width: 100%;
  }
}

.thumbnail {
  max-width: 50px;
  margin-top:3px;
}


ul.dropdown-cart{
    min-width:300px;
}
ul.dropdown-cart li .item{
    display:block;
    padding:3px 10px;
    margin: 3px 0;
}
ul.dropdown-cart li .item:hover{
    background-color:#f3f3f3;
}
ul.dropdown-cart li .item:after{
    visibility: hidden;
    display: block;
    font-size: 0;
    content: " ";
    clear: both;
    height: 0;
}

ul.dropdown-cart li .item-left{
    float:left;
}
ul.dropdown-cart li .item-left img,
ul.dropdown-cart li .item-left span.item-info{
    float:left;
}
ul.dropdown-cart li .item-left span.item-info{
    margin-left:10px;   
}
ul.dropdown-cart li .item-left span.item-info span{
    display:block;
}
ul.dropdown-cart li .item-right{
    float:right;
}
ul.dropdown-cart li .item-right button{
    margin-top:4px;
    margin-left: 10px;
}


</style>