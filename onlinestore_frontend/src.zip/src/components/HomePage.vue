<template>
  <div class="container-fluid">
      <router-link to="/" replace>
    <mdb-carousel
    slide
    :items="basicCarousel"
    indicators
  ></mdb-carousel>
  </router-link>

  <div class="container mt-5">
  <!--Section: Content-->
  <section class="dark-grey-text text-center">
    
    <!-- Section heading -->
    <img class="news-tile view zoom z-depth-1 rounded mb-4" src="@/assets/newbooks2.png"/>
  
    <!-- Section description -->
   
  	<!-- Carousel Wrapper -->
    <div id="multi-item-example" class="carousel slide carousel-multi-item" data-ride="carousel">
      <!-- Controls -->
      <div class="controls-top">
        <a class="btn-floating primary-color waves-effect waves-light" href="#multi-item-example" data-slide="prev">
          <i class="fas fa-chevron-left"></i>
        </a>
        <a class="btn-floating primary-color waves-effect waves-light" href="#multi-item-example" data-slide="next">
          <i class="fas fa-chevron-right"></i>
        </a>
      </div>
      <!-- Controls -->
      <!-- Indicators -->
      <ol class="carousel-indicators mb-n3">
        <li class="primary-color active" data-target="#multi-item-example" data-slide-to="0"></li>
        <li class="primary-color" data-target="#multi-item-example" data-slide-to="1"></li>
        <li class="primary-color" data-target="#multi-item-example" data-slide-to="2"></li>
      </ol>
      <!-- Indicators -->
      <!-- Slides -->
      <div class="carousel-inner" role="listbox ">
        <!-- First slide -->
        <div class="carousel-item active" >
          <div class="row">
          <div class="col-md-3 mb-2" v-for="product in books" :key="product.id" >
            <!-- Card -->
            <div class="card card-cascade narrower card-ecommerce"  >
              <!-- Card image -->
              <div class="view view-cascade overlay">
                <router-link :to="{ name: 'product', params: { id: product.pId } }" replace><img class ="img-thumbnail" v-bind:src="product.image"/></router-link>
               
                <a>
                  <div class="mask rgba-white-slight"></div>
                </a>
              </div>
              <!-- Card image -->
              <!-- Card content -->
              <div class="card-body card-body-cascade text-center">
                <!-- Category & Title -->
                <a href="" class="text-muted">
                  <h5>Books</h5>
                </a>
                <h4 class="card-title my-4">
                  <strong>
                    <a href="">{{product.pName}}</a>
                  </strong>
                </h4>
                <!-- Description -->
                <p class="card-text">{{product.description.substring(0,80)+".."}}
                </p>
                <!-- Card footer -->
                <div class="card-footer px-1">
                  <span class="float-left">${{product.sellingPrice}}</span>
                  <span class="float-right">
                  <a class="" data-toggle="tooltip" data-placement="top" title="Add to Cart">
                    <button class="btn-sm btn purple-gradient" @click="addToCart(product)">
                    <i class="fas fa-shopping-cart ml-3" aria-hidden="true"></i>
                    </button>
                   </a>
                  <a class="" data-toggle="tooltip" data-placement="top" title="Add to Wishlist">
                    <button class="btn-sm btn purple-gradient" >
                    <i class="fas fa-heart grey-text ml-3"></i> 
                    </button>
                  </a>
                </span>
                </div>
              </div>
            </div>
            </div>
              </div>
              <!-- Card content -->
            </div>
            <!-- Card -->
          </div>
    </div>
    <!-- Carousel Wrapper -->
  </section>
  <!--Section: Content-->
</div>

  <div class="container mt-5">
  <!--Section: Content-->
  <section class="dark-grey-text text-center">
    
    <!-- Section heading -->
     <img class="news-tile view zoom z-depth-1 rounded mb-4" src="@/assets/newmusic2.png"/>
    <!-- Section description -->
   
  	<!-- Carousel Wrapper -->
    <div id="multi-item-example" class="carousel slide carousel-multi-item" data-ride="carousel">
      <!-- Controls -->
      <div class="controls-top">
        <a class="btn-floating primary-color waves-effect waves-light" href="#multi-item-example" data-slide="prev">
          <i class="fas fa-chevron-left"></i>
        </a>
        <a class="btn-floating primary-color waves-effect waves-light" href="#multi-item-example" data-slide="next">
          <i class="fas fa-chevron-right"></i>
        </a>
      </div>
      <!-- Controls -->
      <!-- Indicators -->
      <ol class="carousel-indicators mb-n3">
        <li class="primary-color active" data-target="#multi-item-example" data-slide-to="0"></li>
        <li class="primary-color" data-target="#multi-item-example" data-slide-to="1"></li>
        <li class="primary-color" data-target="#multi-item-example" data-slide-to="2"></li>
      </ol>
      <!-- Indicators -->
      <!-- Slides -->
      <div class="carousel-inner" role="listbox">
        <!-- First slide -->
        <div class="carousel-item active" >
          
            <!-- Card -->
            <div class="row">
            <div class="col-md-3 mb-2" v-for="product in music" :key="product.id" >

            <div class="card card-cascade narrower card-ecommerce"  >
              <!-- Card image -->
              <div class="view view-cascade overlay">
                <router-link :to="{ name: 'product', params: { id: product.pId } }" replace><img class="img-thumbnail" v-bind:src="product.image"/></router-link>
              
                <a>
                  <div class="mask rgba-white-slight"></div>
                </a>
              </div>
              <!-- Card image -->
              <!-- Card content -->
              <div class="card-body card-body-cascade text-center">
                <!-- Category & Title -->
                <a href="" class="text-muted">
                  <h5>Music</h5>
                </a>
                <h4 class="card-title my-4">
                  <strong>
                    <a href="">{{product.pName}}</a>
                  </strong>
                </h4>
                <!-- Description -->
                <p class="card-text">{{product.description.substring(0,80)+".."}}
                </p>
                <!-- Card footer -->
                <div class="card-footer px-1">
                  <span class="float-left">${{product.sellingPrice}}</span>
                  <span class="float-right">
                  <a class="" data-toggle="tooltip" data-placement="top" title="Add to Cart">
                    <button class="btn-sm btn purple-gradient" @click="addToCart(product)">
                    <i class="fas fa-shopping-cart ml-3" aria-hidden="true"></i>
                    </button>
                   </a>
                  <a class="" data-toggle="tooltip" data-placement="top" title="Add to Wishlist">
                    <button class="btn-sm btn purple-gradient" >
                    <i class="fas fa-heart grey-text ml-3"></i> 
                    </button>
                  </a>
                </span>
                </div>
              </div>
            </div>
            </div>
              </div>
              <!-- Card content -->
            </div>
            
            <!-- Card -->
          </div>
          
  
    </div>
    <!-- Carousel Wrapper -->

  </section>
  <!--Section: Content-->
</div>

  <div class="container mt-5">
  <!--Section: Content-->
  <section class="dark-grey-text text-center">
    
    <!-- Section heading -->
    <img class="news-tile view zoom z-depth-1 rounded mb-4" src="@/assets/newdvd2.png"/>
    
  	<!-- Carousel Wrapper -->
    <div id="multi-item-example" class="carousel slide carousel-multi-item" data-ride="carousel">
      <!-- Controls -->
      <div class="controls-top">
        <a class="btn-floating primary-color waves-effect waves-light" href="#multi-item-example" data-slide="prev">
          <i class="fas fa-chevron-left"></i>
        </a>
        <a class="btn-floating primary-color waves-effect waves-light" href="#multi-item-example" data-slide="next">
          <i class="fas fa-chevron-right"></i>
        </a>
      </div>
      <!-- Controls -->
      <!-- Indicators -->
      <ol class="carousel-indicators mb-n3">
        <li class="primary-color active" data-target="#multi-item-example" data-slide-to="0"></li>
        <li class="primary-color" data-target="#multi-item-example" data-slide-to="1"></li>
        <li class="primary-color" data-target="#multi-item-example" data-slide-to="2"></li>
      </ol>
      <!-- Indicators -->
      <!-- Slides -->
      <div class="carousel-inner" role="listbox">
        <!-- First slide -->
        <div class="carousel-item active">
          <div class="row ">
          <div class="view col-md-3 mb-2 fluid"   v-for="product in dvd" :key="product.id">
            <!-- Card -->
            <div class="card card-cascade narrower card-ecommerce" >
              <!-- Card image -->
              <div class="view view-cascade overlay">
                <router-link :to="{ name: 'product', params: { id: product.pId } }" replace><img  class="img-thumbnail" v-bind:src="product.image"/></router-link>
               
                <a>
                  <div class="mask rgba-white-slight"></div>
                </a>
              </div>
              <!-- Card image -->
              <!-- Card content -->
              <div class="card-body card-body-cascade text-center">
                <!-- Category & Title -->
                <a href="" class="text-muted">
                  <h5>DVD</h5>
                </a>
                <h4 class="card-title my-4">
                  <strong>
                    <a href="">{{product.pName.substring(0,15)+".."}}</a>
                  </strong>
                </h4>
                <!-- Description -->
                <p class="card-text">{{product.description.substring(0,80)+".."}}
                </p>
                <!-- Card footer -->
                <div class="card-footer px-1">
                  <span class="float-left">${{product.sellingPrice}}</span>
                  <span class="float-right">
                  <a class="" data-toggle="tooltip" data-placement="top" title="Add to Cart">
                    <button class="btn-sm btn purple-gradient" @click="addToCart(product)">
                    <i class="fas fa-shopping-cart ml-3" aria-hidden="true"></i>
                    </button>
                   </a>
                  <a class="" data-toggle="tooltip" data-placement="top" title="Add to Wishlist">
                    <button class="btn-sm btn purple-gradient" >
                    <i class="fas fa-heart grey-text ml-3"></i> 
                    </button>
                  </a>
                </span>
                </div>
              </div>
            </div>
            </div>
              </div>
              <!-- Card content -->
            </div>
            <!-- Card -->
          </div>
  
    </div>
    <!-- Carousel Wrapper -->

  </section>
  <!--Section: Content-->
</div>
</div>
</template>

<script>
import { Carousel, Slide } from 'vue-carousel';
import { mdbCarousel } from "mdbvue";
import axios from 'axios';
export default {
  name: 'Homepage',
  data() {
    return { books: [],music:[],dvd:[] ,
        carousel: 2,
        basicCarousel: [
          {
            img: true,
            src:
           require("../assets/bestsellers2.png"),
            mask: "black-light",
            alt: "First Slide",
            
          },
          {
            img: true,
            src:
              require("../assets/slide2.png"),
            mask: "black-strong",
            
          },
          {
            img: true  ,
           
            src:
               require("../assets/slide3.png"),
            mask: "black-slight",
           
          }
        ]
 };
  },

  methods:{

      addToCart(product) {
      axios.post("http://localhost:8090/shoppingCart/add-To-Cart",{cId:2, pId:product.pId,pName:product.pName, price:product.price,image:product.image,quantity:1})
    }
  },
 
  components: {
    Carousel,
    Slide,
     mdbCarousel
  },
 

  mounted(){
    axios.get("http://localhost:8090/product/get-by-type/?type=book")
    .then(response=> this.books=response.data)
    axios.get("http://localhost:8090/product/get-by-type/?type=music")
    .then(response=> this.music=response.data)
    axios.get("http://localhost:8090/product/get-by-type/?type=dvd")
    .then(response=> this.dvd=response.data)
    
  },
  
  
 

};
</script>

<style scoped>
container {
  display: grid;
  grid-template-rows: auto;
  grid-template-columns: repeat(2, 70%);
}
h1 {
  padding-top: 20px;
}
slide {
  height: 100px;
  width: 200px;
}
.view:hover {
    cursor: pointer;
}

.img-thumbnail{

  border:2px;
  width:100%;
  height:350px;
}
</style>
