<template>
  <div class="container">
    
   
    <h4 class="font-weight-bold text-center dark-grey-text mb-5 ">Search Results for...</h4>
    
    <!-- Grid row -->
    <div v-for="(chunk,i) in groupedProducts" :key=i class="row">
      <!-- Grid column -->
      <div class="col-md-3 mb-4" v-for="product in chunk" :key="product.pId">
        <!-- Card -->
        <div class="card card-ecommerce">
          <!-- Card image -->
          <div class="view overlay">
            <router-link :to="{ name: 'product', params: { id: product.pId } }" replace
           ><img  v-bind:src="product.image" class="img-thumbnail"
              alt="">
               </router-link>
            <a>
              <div class="mask rgba-white-slight"></div>
            </a>
          </div>
          <!-- Card image -->
          <!-- Card content -->
          <div class="card-body">
            <!-- Category & Title -->
            <h5 class="card-title mb-2">
              <strong>
                <a href="" class="dark-grey-text">{{product.pName}}</a>
              </strong>
            </h5>
            <span class="badge badge-danger mb-2">bestseller</span>
            <!-- Rating -->
            
            <!-- Card footer -->
            <div class="card-footer pb-0">
              <div class="row mb-0">
                <span class="float-left">
                  <strong>${{product.sellingPrice}}</strong>
                </span>
                <span class="float-right">
                  <button class="btn-sm btn purple-gradient" @click="addToCart()"></button>
                    <i class="fas fa-shopping-cart ml-3" aria-hidden="true"></i>

                    <button class="btn-sm btn purple-gradient" >
                    <i class="fas fa-heart grey-text ml-3"></i> 
                    </button>
                </span>
              </div>
            </div>
         
          </div>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
import { Carousel, Slide } from 'vue-carousel';


export default {
  name: 'SearchResults',

  data() {
    return { products: [], searchProduct: this.$store.state.searchProducts};
  },
  computed:{
    groupedProducts() {
      return _.chunk(this.searchProduct, 4)
    }
  },
  methods:{

      addToCart() {
      axios.post("http://localhost:8090/shoppingCart/add-To-Cart",{cId:2, pId:this.product.pId,pName:this.product.pName, price:this.product.price,image:this.product.image,quantity:1})
    }
  },
 
  

};
</script>

<style scoped>
container {
  display: grid;
  grid-template-rows: auto;
  grid-template-columns: repeat(4, 25%);
}
h1 {
  padding-top: 20px;
}
slide {
  height: 100px;
  width: 100px;
}

.img-thumbnail{

  border:2px;
  width:100%;
  height:250px;
}
</style>