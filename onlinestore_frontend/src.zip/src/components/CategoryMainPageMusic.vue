
<template>

  <div class="container-fluid">
 
  <img class="rounded" src="../assets/Music.png" alt="" />
   

 <!--Section: Content-->
    <section  class="row-fluid justify-content-start ml-4">
      <p class="text-left font-weight-bold ml-5 mt-4">  Filter panel</p>  
      <!--Grid row-->
      <div class="row d-flex ju stify-content-start">
        
        <!--Grid column-->
        <div class="col-lg-2  ml-5  border p-4">

          <!-- Filter panel -->
          
          <div class="mb-5">
            <h5 class="font-weight-bold mb-3">Order by</h5>

            <div class="divider-small mb-3"></div>

            <ul class="list-unstyled link-black">
              <li class="mb-2">
                <a href="" class="active">Default</a>
              </li>
              <li class="mb-2">
                <a href="" class="">Popularity</a>
              </li>
              <li class="mb-2">
                <a href="" class="">Rating</a>
              </li>
              <li class="mb-2">
                <a href="" class="">Price: low to high</a>
              </li>
              <li class="mb-2">
                <a href="" class="">Price: high to low</a>
              </li>
            </ul>
          </div>
          <!-- Filter panel -->

          <!-- Filter panel -->
          <div class="mb-5">

            <h5 class="font-weight-bold mb-3">Category</h5>

            <div class="divider-small mb-3"></div>

            <div class="form-check pl-0 mb-2">
              <input type="radio" class="form-check-input" id="materialGroupExample1" name="groupOfMaterialRadios">
              <label class="form-check-label" for="materialGroupExample1">All</label>
            </div>

            <div class="form-check pl-0 mb-2">
              <input type="radio" class="form-check-input" id="materialGroupExample2" name="groupOfMaterialRadios"
                checked>
              <label class="form-check-label" for="materialGroupExample2">Horror</label>
            </div>

            <div class="form-check pl-0 mb-2">
              <input type="radio" class="form-check-input" id="materialGroupExample3" name="groupOfMaterialRadios">
              <label class="form-check-label" for="materialGroupExample3">Romantic</label>
            </div>

            <div class="form-check pl-0 mb-2">
              <input type="radio" class="form-check-input" id="materialGroupExample4" name="groupOfMaterialRadios">
              <label class="form-check-label" for="materialGroupExample4">Comedy</label>
            </div>

          </div>
          <!-- Filter panel -->

          <!-- Filter panel -->
          <div class="mb-5">

            <h5 class="font-weight-bold mb-3">Price</h5>

            <div class="divider-small mb-3"></div>

            <form class="range-field">
              <input type="range" min="0" max="319" />
            </form>

            <div class="row justify-content-start">

              <!-- Grid column -->
              <div class="col-md-6 text-left">
                <p class="dark-grey-text"><strong id="resellerEarnings">0$</strong></p>
              </div>
              <!-- Grid column -->

              <!-- Grid column -->
              <div class="col-md-6 text-right">
                <p class="dark-grey-text"><strong id="clientPrice">319$</strong></p>
              </div>
              <!-- Grid column -->
            </div>

          </div>
          <!-- Filter panel -->

          <!-- Filter panel -->
          <div class="link-black">

            <h5 class="font-weight-bold mb-3">Rating</h5>

            <div class="divider-small mb-3"></div>

            <div class="amber-text fa-sm mb-1">
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <a href="" class="ml-2 active">4 and more</a>
            </div>

            <div class="amber-text fa-sm mb-1">
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <a href="" class="ml-2">3 - 3,99</a>
            </div>

            <div class="amber-text fa-sm mb-1">
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <a href="" class="ml-2">3.00 and less</a>
            </div>

          </div>
          <!-- Filter panel -->

        </div>

    <div class="col-lg-7 offset-md-1  border p-4">
    <h3 class="font-weight-bold text-center dark-grey-text mb-5 ">All Music</h3>
    
    <!-- Grid row -->
    <div v-for="(chunk,i) in groupedProducts" :key=i class="row">
      <!-- Grid column -->
      <div class="col-lg-6 mb-4" v-for="product in chunk" :key="product.pId">
        <!-- Card -->
        <div class="card card-ecommerce">
          <!-- Card image -->
          <div class="view overlay">
            <router-link :to="{ name: 'product', params: { id: product.pId } }" replace
           ><img  v-bind:src="product.image" class="img-thumbnail"
              alt="">
               </router-link>
            <a>
              <div class="mask rgba-white-slight"></div>
            </a>
          </div>
          <!-- Card image -->
          <!-- Card content -->
          <div class="card-body">
            <!-- Category & Title -->
            <h5 class="card-title mb-1">
              <strong>
                <a href="" class="dark-grey-text">{{product.pName}}</a>
              </strong>
            </h5>
            <span class="badge badge-danger mb-2">bestseller</span>
            <!-- Rating -->
            
            <!-- Card footer -->
            <div class="card-footer pb-0">
              <div class="row mb-0">
                <span class="float-left">
                  <strong>${{product.sellingPrice}}</strong>
                </span>
                <span class="float-right">
                  <a class="" data-toggle="tooltip" data-placement="top" title="Add to Cart">
                    <button class="btn-sm btn purple-gradient" @click="addToCart(product)">
                    <i class="fas fa-shopping-cart ml-3" aria-hidden="true"></i>
                    </button>
                   </a>
                  <a class="" data-toggle="tooltip" data-placement="top" title="Add to Wishlist">
                    <button class="btn-sm btn purple-gradient" >
                    <i class="fas fa-heart grey-text ml-3"></i> 
                    </button>
                  </a>
                </span>
              </div>
            </div>
            </div>
          </div>
        </div>
      </div>
    </div>
        <!--Grid column-->

      </div>
      <!--Grid row-->
    </section>
    <!--Section: Content-->

</div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'mainmusic',

  data() {
    return {
      products: [],
      
    };
  },
  computed:{
    groupedProducts() {
      return _.chunk(this.products, 4)
    }
  },
  methods:{

      addToCart(product) {
       axios.post("http://localhost:8090/shoppingCart/add-To-Cart",{cId:2, pId:product.pId,pName:product.pName, price:product.price,image:product.image,quantity:1})
    }
  },

 
  mounted(){
    axios.get("http://localhost:8090/product/get-by-type/?type=music")
    .then(response=> this.products=response.data)
    .catch(() => console.log("Can’t access response. Blocked by browser?"));
    
  }

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>


h1 {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  margin-top: 10%;
  padding-left: 10%;
  color: #993c3c;
  position: absolute;
}

.img-thumbnail{

  border:2px;
  width:50%;
  height:250px;
}

</style>
