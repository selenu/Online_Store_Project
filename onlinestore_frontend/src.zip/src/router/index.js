import Vue from "vue";
import VueRouter from "vue-router";
import Home from "../views/Home.vue";
import Product from "../components/Product.vue";
import mainbooks from "../components/CategoryMainPageBooks.vue";
import mainmusic from "../components/CategoryMainPageMusic.vue";
import maindvd from "../components/CategoryMainPageDvd.vue";
import SearchResults from "../components/SearchResults.vue";
import checkout from "../components/Checkout.vue";
import signup from "../components/Signup.vue";
import Login from "../components/Login.vue";
import Literature from "../components/CategorySubcComponent.vue";

Vue.use(VueRouter);

const routes = [
  
  
  {path: "/",name: "Home", component: Home},
  {path: '/products:id',name: 'product',component: Product},
  {path: '/maincategorybooks',name: 'maincategorybooks',component: mainbooks},
  {path: '/maincategorymusic',name: 'maincategorymusic',component: mainmusic},
  {path: '/maincategorydvd',name: 'maincategorydvd',component: maindvd},
  {path: "/checkout",name: "checkout", component: checkout},
  {path: "/signup",name: "signup", component: signup},
  {path: "/login",name: "login", component: Login},
  {path: "/SearchResults/",name: "SearchResults", component: SearchResults},
  {path: "/Literature/",name: "Literature", component: Literature},
 
  
];

const router = new VueRouter({
  routes
});

export default router;
